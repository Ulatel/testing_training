import requests

BASE_URL = 'http://localhost:5000/'

def get_array_list():
    response = requests.get(BASE_URL)
    return response

def post_create_array(title, content):
    post_data = {
        "title": title,
        "content": content
        }
    response = requests.post(BASE_URL+"create", data=post_data)
    return response

def post_edit_array(id, title, content):
    post_data = {
        "title": title,
        "content": content
        }
    response = requests.post(BASE_URL+id+"/edit", data=post_data)
    return response

def post_delete_array(id):
    response = requests.post(BASE_URL+id+"/delete")
    return response

def post_pos_target_in_array(id, target):
    post_data={"target": str(target)}
    response = requests.post(BASE_URL+str(id), data=post_data)
    return response